# Business concepts

* [Order](concept-bb3ef4f687a6d407f134ce669a112277.md) - A confirmed purchase agreement with a customer.
