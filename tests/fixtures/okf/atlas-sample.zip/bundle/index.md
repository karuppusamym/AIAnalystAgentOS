---
okf_version: '0.2'
---

# Bundle

* Scope: CONTEXT_PRODUCT.
* Context product: `revenue_context` version 2.
* Sources in scope: 1.
* Objects in scope: 2 (routines 3, packages 1).
* Business concepts: 1.
* Approved purpose: Support bounded revenue analysis.
* Every count on this page is over the objects the reader was authorized to see. Nothing outside that authority is counted, linked or named anywhere in this bundle.
* Source values are not in this bundle. A current figure needs an approved Atlas tool through the query gateway, and its execution receipt.

# Sources

* [warehouse](sources/source-5fd38562543a9e68b3db7de8b75d87c5/) - postgres source, 1 schema(s) in scope

# Business meaning

* [Concepts](concepts/) - 1 approved concept(s)
