# Source

* Engine: postgres (connector `postgres`).
* Environment: PROD.
* Lifecycle: ACTIVE.
* This page is navigational. It describes what Atlas holds about the source, and does not assert a business purpose for it.

# Schemas

* [bank.sales](schemas/schema-6b81a211195841967070277dc63d5744/) - 2 object(s), 3 routine(s) in scope
