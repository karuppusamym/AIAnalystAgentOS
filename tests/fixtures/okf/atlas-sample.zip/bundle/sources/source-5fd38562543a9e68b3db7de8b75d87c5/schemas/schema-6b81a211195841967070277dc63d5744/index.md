# Schema

* Catalog: `bank`.
* Lifecycle: ACTIVE.
* Navigational only: no business purpose is asserted for a schema.

# Tables

* [bank.sales.orders](tables/table-eecde9b0abfa5ed6c95a70064d99018b.md) - One row per completed order.

# Views

* [bank.sales.orders_v](views/view-370c77a6a6cd337e196c0962b331a548.md) - VIEW, no approved description

# Routines

* [bank.sales.rebuild(integer)](routines/routine-ce6dd97768ce88648a706fb5ffd84624.md) - PROCEDURE, no approved description
* [bank.sales.rebuild(numeric)](routines/routine-3a49531ffaea9fb61a617a85527e22c4.md) - PROCEDURE, no approved description
* [bank.sales.risk_pkg.rebuild(integer)](routines/routine-e3610d816a9eefa92dfefe99594d683d.md) - PROCEDURE, no approved description

# Packages

* [bank.sales.risk_pkg](packages/package-ea0f49af5d702df741965f99695fd93d.md) - 1 member(s) in scope
