---
atlas:
  description:
    state: NONE
    version: null
  object:
    engine: postgres
    key: e3610d816a9eefa92dfefe99594d683d
    kind: ROUTINE
    lifecycle: ACTIVE
    native_object_type: PROCEDURE
    qualified_name: bank.sales.risk_pkg.rebuild
  profile: atlas-okf-export/4
  routine:
    is_deterministic: null
    language: null
    package_name: risk_pkg
    return_type: null
    routine_type: PROCEDURE
    security_mode: null
    signature: (integer)
  scope:
    kind: CONTEXT_PRODUCT
    policy_partition_digest: cac018080b7daa0d90e15a290164640ce09b79e0c0e274e780702b049ab6593f
    product_key: revenue_context
    product_version: 2
  statements:
    approved: []
    derived:
    - coverage
    - interface
    - reads-and-writes
generated:
  by: process:atlas-okf-export
resource: atlas://source/5fd38562543a9e68b3db7de8b75d87c5/schema/6b81a211195841967070277dc63d5744/routine/e3610d816a9eefa92dfefe99594d683d
status: draft
tags:
- atlas
- postgres
- procedure
- routine
title: bank.sales.risk_pkg.rebuild
type: Atlas Routine
---

# Purpose

Not established. No approved description of this routine exists.

# Interface

* Kind: PROCEDURE.
* Signature: `(integer)`.
* Package member of `risk_pkg`.

No parameters are captured for this routine.

# Coverage

* Definition: not captured (`DEFINITION_NOT_CAPTURED`).

The routine body is never exported. Atlas releases code text only through its own authorized read, and a bundle is a file that cannot be revoked.
