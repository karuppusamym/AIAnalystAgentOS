---
atlas:
  description:
    approved_at: '2026-09-02T00:00:00+00:00'
    approved_by: human:steward
    state: APPROVED
    version: 3
  object:
    engine: postgres
    key: eecde9b0abfa5ed6c95a70064d99018b
    kind: TABLE
    lifecycle: ACTIVE
    native_object_type: BASE_TABLE
    qualified_name: bank.sales.orders
  profile: atlas-okf-export/4
  scope:
    kind: CONTEXT_PRODUCT
    policy_partition_digest: cac018080b7daa0d90e15a290164640ce09b79e0c0e274e780702b049ab6593f
    product_key: revenue_context
    product_version: 2
  statements:
    approved:
    - purpose
    derived:
    - columns
    - coverage
    - dependencies
description: One row per completed order.
generated:
  at: '2026-09-02T00:00:00+00:00'
  by: process:atlas-okf-export
resource: atlas://source/5fd38562543a9e68b3db7de8b75d87c5/schema/6b81a211195841967070277dc63d5744/table/eecde9b0abfa5ed6c95a70064d99018b
sources:
- author: human:steward
  id: approved-description
  last_modified: '2026-09-02T00:00:00+00:00'
  resource: atlas://source/5fd38562543a9e68b3db7de8b75d87c5/schema/6b81a211195841967070277dc63d5744/table/eecde9b0abfa5ed6c95a70064d99018b/description
  title: Approved Atlas description version 3
status: stable
tags:
- atlas
- postgres
- table
title: bank.sales.orders
type: Atlas Table
---

# Purpose

One row per completed order.[^approved-description]

# Schema

| Column | Type | Nullable | Classification | Description |
|---|---|---|---|---|
| `order_id` | `uuid` | no | INTERNAL | The order's identifier. |

# Dependencies

* [bank.sales.rebuild(integer)](/sources/source-5fd38562543a9e68b3db7de8b75d87c5/schemas/schema-6b81a211195841967070277dc63d5744/routines/routine-ce6dd97768ce88648a706fb5ffd84624.md) - written by

# Coverage

* Columns captured: 1.
* Definition: a base table has none; its shape is the schema above.

Source read times are recorded in the Atlas manifest beside this bundle, not here: a completed scan that changed nothing must not change this document.

[^approved-description]: Approved Atlas description version 3, approved by human:steward at 2026-09-02T00:00:00+00:00.
